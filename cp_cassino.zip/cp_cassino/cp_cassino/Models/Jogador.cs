﻿using System.Collections.Generic;

namespace cp_cassino.Models
{
    public class Jogador
    {
        public string Nome { get; set; }
        private List<int> Cartas { get; set; }

        internal bool EstaParticipando { get; set; } // Exemplo de propriedade internal

        public Jogador(string nome)
        {
            Nome = nome;
            Cartas = new List<int>();
            EstaParticipando = false; // Inicializando como false
        }

        public void ParticiparDoJogo(Jogo jogo)
        {
            jogo.Jogar();
        }
        public void ReceberCarta(int carta)
        {
            Cartas.Add(carta);
        }

        public int CalcularPontuacao()
        {
            return Cartas.Sum();
        }

    }
}