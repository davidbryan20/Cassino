﻿namespace cp_cassino.Models
{
    public class Jogo
    {
        protected string nome;

        public Jogo(string nome)
        {
            this.nome = nome;
        }

        public virtual void Jogar()
        {
            Console.WriteLine($"Jogando {nome}...");
        }
    }
}
