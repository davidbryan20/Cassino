﻿namespace cp_cassino.Models
{
    public class Blackjack : Jogo
    {
        public Blackjack() : base("21 (Blackjack)") { }

        public override void Jogar()
        {
            base.Jogar();
        }
    }
}

