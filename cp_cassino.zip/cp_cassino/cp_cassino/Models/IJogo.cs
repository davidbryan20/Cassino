﻿namespace cp_cassino.Models
{
    public interface IJogo
    {
        void Jogar();
    }
}
