﻿namespace cp_cassino.Models
{
    public class Roleta : Jogo
    {
        public Roleta() : base("Roleta") { }

        public override void Jogar()
        {
            base.Jogar();
            Console.WriteLine("Girando a roleta...");
        }
    }

}
