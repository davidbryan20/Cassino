﻿namespace cp_cassino.Models
{
    public class JogoViewModel
    {
        public string JogadorNome { get; set; } = " ";
        public string JogoEscolhido { get; set; } = " ";
        public int CartaRecebida { get; set; } 
    }
}
