﻿using Microsoft.AspNetCore.Mvc;

namespace cp_cassino.Models
{
    public class CassinoController : Controller
    {
        // GET: /Cassino/
        public IActionResult Index()
        {
            return View();
        }

        // Método para iniciar o jogo
        public IActionResult IniciarJogo(string jogadorNome, string jogoEscolhido)
        {
            // Lógica para iniciar o jogo...
            // Neste ponto, você pode redirecionar para a View de jogo passando informações do jogador e do jogo.
            return View("Jogo", new JogoViewModel { JogadorNome = jogadorNome, JogoEscolhido = jogoEscolhido });
        }

        // Ação para distribuir cartas
        [HttpPost]
        public IActionResult DistribuirCartas(string jogadorNome)
        {
            Jogador jogador = new Jogador(jogadorNome);
            Random random = new Random();
            int carta = random.Next(1, 22); // Gera um número aleatório de 1 a 21
            jogador.ReceberCarta(carta);

            // Lógica para redirecionar para a próxima etapa do jogo ou atualizar a View com a carta recebida.
            return RedirectToAction("ProximaEtapaDoJogo");
        }
    }
}

